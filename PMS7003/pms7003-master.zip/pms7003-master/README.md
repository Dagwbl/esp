# pms7003_esp
Dust monitor consisting of an ESP8266 forwarding data from a Plantower PMS7003 dust sensor

See also https://revspace.nl/DustSensor
